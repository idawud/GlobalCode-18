sentence= """Write a function called calculate that takes one string and two int arguments. The string should be "add","subtract", "multiply" or "divide", or any of those words in uppercase"""

split = sentence.split(" ")
print(split)
print("\n")
