import math 

 # converting degree to radian  

rad = 32  * ( math.pi / 180)
print(" 32 degrees in Radian is : " + str(rad))
print("\n")

