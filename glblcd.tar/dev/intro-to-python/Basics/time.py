import datetime

# print local time
localtime = datetime.datetime.now()
print ("Current time is : ", localtime)
