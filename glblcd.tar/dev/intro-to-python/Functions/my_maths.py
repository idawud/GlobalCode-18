def calculate(operation, num1,num2):
	if operation == "add":
		return ( num1 + num2)
	elif operation == "subtract":
		return ( num1 - num2)
	elif operation == "multiply":
		return ( num1 * num2)
	elif operation == "divide":
		return ( num1 / num2)

value = calculate("divide", 6,2)
print("The value is: ",value)
